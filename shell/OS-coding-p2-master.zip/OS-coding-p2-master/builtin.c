/*CSC 501 Operating Systems Programming Assignment P2
* Micro Shell ush
* Anand Jayaram
* builtin.c
* dependencies: parse
*/
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <stdlib.h>
#include <string.h>
#include "parse.h"

/*To get logs, use "make log"*/
#ifdef LOGPRINT
#define log(message){printf(">>\t\tLOG: %s\n",message);}
#else
#define log(message){do{}while(0);}
#endif

/*is a builtin command check*/
int isBuiltIn(char * command){
	if (strcmp(command, "cd") == 0)
		return 1;
    if (strcmp(command, "echo")== 0)
		return 1;
    if (strcmp(command, "logout")== 0)
		return 1;
    if (strcmp(command, "nice")== 0)
		return 1;
    if (strcmp(command, "pwd")== 0)
		return 1;
    if (strcmp(command, "setenv")== 0)
		return 1;
    if (strcmp(command, "unsetenv")== 0)
        return 1;
    if (strcmp(command, "where")== 0)
		return 1;
	return 0;
}

int execCD(Cmd c){
	int status = 0;
	log("inside cd");
	if(c->nargs > 1)		
		status = chdir(c->args[1]);
	else
		status = chdir(getenv("HOME"));
	if(status != 0){
		perror("USH: cd:");
	}
	return status;
}

int execECHO(Cmd c){
	int i;
	log("inside echo");
	if(c->nargs == 1)
		write(STDOUT_FILENO,"\n",sizeof("\n"));
	else {
		for(i = 1 ; i <= c->nargs ; i++){
			write(STDOUT_FILENO, c->args[i],sizeof(c->args[i]));
			write(STDOUT_FILENO, " ",sizeof(" "));
		}
		write(STDOUT_FILENO,"\n",sizeof("\n"));
	}
	return 0;
}

int execLOGOUT(){
	log("inside logout");
	exit(EXIT_SUCCESS);
	return 0;
}

int isADigit (char c) {
    if (c == '+' || c == '-' || (c >= '0' && c <= '9') ) {
        return 1;
    }
    return 0;
}

int execNICE(Cmd c){
	int waitStatus,shellID,forkID;
	shellID = getpid();
	/*Part of this function was obtained from someone else's work. check references*/
	if (c->nargs == 1)
		setpriority(PRIO_PROCESS, shellID, 4);
    else if (c->nargs == 2 && isADigit(*(c->args[1])))
		setpriority(PRIO_PROCESS, shellID, atoi(c->args[1]));
    else if (c->nargs == 3 || !isADigit(*(c->args[1]))) {
		forkID = fork();                     
		if (forkID == 0) {
			setpriority(PRIO_PROCESS, forkID, atoi(c->args[1]));
			execvp(c->args[2], &(c->args[2]));
            exit(EXIT_FAILURE);
        } else {                             
            do {
				waitpid(forkID, &waitStatus, WUNTRACED);
			} while (!WIFEXITED(waitStatus) && !WIFSIGNALED(waitStatus));
        }
    }
	return 0;
}

int execPWD(){
	log("inside pwd");
	char *pwd = (char*)malloc(40*sizeof(char));
	getcwd(pwd,40);
	printf("%s\n",pwd);
	free(pwd);
	return 0;
}

int execSETENV(Cmd c){
	extern char **environ;
	int i = 0;
	log("inside setenv");
	if(c->nargs == 1){
		while(environ[i]) {
			printf("%s\n",environ[i++]);
		}
	}else if (c->nargs == 2){
		setenv(c->args[1],"",1);
	}else 
		setenv(c->args[1],c->args[2],1);
	free(environ);
	return 0;
}
int execUNSETENV(Cmd c){
	log("inside unsetenv");
	if(c->nargs == 2)
		unsetenv(c->args[1]);
	else 
		return -1;
	return 0;
}

void execWHERE(Cmd c){
	log("inside where");
	if(c->nargs ==1){
		printf("not enough arguments\n");
		return;
	}
	char *pathAll, *path;
	char *command = c->args[1];
	int no = 0;
    if (isBuiltIn(command)){
		no ++;
		printf("%s is a shell built-in command\n",command);
	}
	/*parse through PATH**/
	pathAll = strdup(getenv("PATH"));
	while(pathAll) {
		path = strdup(strsep(&pathAll, ":"));
		strcat(path,"/");
		strcat(path,command);
		if(access(path, F_OK) != -1){/*If file exists*/
			printf("%s\n",path);
			no ++;
			break;
		}
	}
	if(no == 0)
		printf("Command not found in PATH\n");
}