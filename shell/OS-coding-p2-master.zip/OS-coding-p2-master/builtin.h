/*CSC 501 Operating Systems Programming Assignment P2
* Micro Shell ush
* Anand Jayaram
* builtin.h
*/
#ifndef BUILTIN_H
#define BUILTIN_H

int isBuiltIn(char * command);

int execCD(Cmd c);

int execECHO(Cmd c);

int execLOGOUT();

int execNICE(Cmd c);

int execPWD();

int isADigit (char c);

int execSETENV(Cmd c);

int execUNSETENV(Cmd c);

int execWHERE(Cmd c);
#endif 