/*CSC 501 Operating Systems Programming Assignment P2
* Micro Shell ush
* Anand Jayaram
* ush.c
* dependencies: parse and builtin
* This file started as "main.c" given by the instructor.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include "parse.h"
#include "builtin.h"

/*To get logs, use "make log"*/
#ifdef LOGPRINT
#define log(message){printf(">>\t\tLOG: %s\n",message);}
#else
#define log(message){do{}while(0);}
#endif

/*Redirect STDIN*/
void redirectInput(char *infile, int FLAGS) {
	int finID;
	log("inside redirectInput");
	finID = open(infile,FLAGS);
	if(finID < 0) {
		log("file open failed");
		perror("Open failed");
		exit(EXIT_FAILURE);
	}
	if(dup2(finID,STDIN_FILENO) == -1) {
		log("dup2 failed");
		perror("dup2 failed");
		exit(EXIT_FAILURE);
	}
	close(finID);
}

/*Redirect STDOUT*/
void redirectOutput(char *outfile, int FLAGS) {
	int foutID;
	log("inside redirectOutput");
	foutID = open(outfile,FLAGS, S_IRWXU | S_IRUSR | S_IWUSR);
	if(foutID < 0) {
		log("file open failed");
		perror("Open failed");
		exit(EXIT_FAILURE);
	}
	if(dup2(foutID,STDOUT_FILENO) == -1) {
		log("dup2 failed");
		perror("dup2 failed");
		exit(EXIT_FAILURE);
	}
	close(foutID);
}
/*Redirect STDOUT and STDERR*/
void redirectOutputError(char *outfile, int FLAGS) {
	int foutID;
	log("inside redirectOutputError");
	foutID = open(outfile,FLAGS,S_IRWXU | S_IRUSR | S_IWUSR);
	if(foutID < 0) {
		log("file open failed");
		perror("Open failed");
		exit(EXIT_FAILURE);
	}
	if(dup2(foutID,STDOUT_FILENO) == -1) {
		log("dup2 failed");
		perror("dup2 failed");
		exit(EXIT_FAILURE);
	}
	if(dup2(foutID,STDERR_FILENO) == -1) {
		log("dup2 failed");
		perror("dup2 failed");
		exit(EXIT_FAILURE);
	}
	close(foutID);
}


void executeBuiltinCommand(Cmd c) {
	log("inside executeBuiltinCommand");
	int flags;
	if(c) {
		if(c->in == Tin) { /*Handle Input redirection*/
			flags = O_RDONLY;
			redirectInput(c->infile,flags);
		}
		
		if (c->out != Tnil) /*Handle Output redirection*/
			switch ( c->out ) {
				case Tout:
					flags = O_CREAT | O_WRONLY; /*create if doesn't exist and open write only*/
					redirectOutput(c->outfile,flags);
					break;
				case Tapp:
					flags = O_CREAT | O_WRONLY| O_APPEND; /*create if doesn't exist and open write only and open append*/
					redirectOutput(c->outfile,flags);
					break;
				case ToutErr:
					flags = O_CREAT | O_WRONLY; /*create if doesn't exist and open write only*/
					redirectOutputError(c->outfile,flags);
					break;
				case TappErr:
					flags = O_CREAT | O_WRONLY | O_APPEND; /*create if doesn't exist and open write only and open append*/
					redirectOutputError(c->outfile,flags);
					break;
				default:
					perror("Redirection Token undefined");
					log("ExecuteCommand default condition on token checking");
					exit(EXIT_FAILURE);
			}
	}
	char * command = (char *)(c->args[0]);
	if (strcmp(command, "cd") == 0)
		execCD(c);
    if (strcmp(command, "echo")== 0)
		execECHO(c);
    if (strcmp(command, "logout")== 0)
		execLOGOUT();
    if (strcmp(command, "nice")== 0)
		execNICE(c);
    if (strcmp(command, "pwd")== 0)
		execPWD();
    if (strcmp(command, "setenv")== 0)
		execSETENV(c);
    if (strcmp(command, "unsetenv")== 0)
		execUNSETENV(c);
    if (strcmp(command, "where")== 0)
		execWHERE(c);
}

void executeCommand(Cmd c, int pipeFD[2]) {
	int flags;
	
	log("inside executeCommand. Calling: ");
	log(c->args[0]);
log("inside executeCommand check 1");
	if(c) {
		if(c->in == Tin) { /*Handle Input redirection*/
			flags = O_RDONLY;
			redirectInput(c->infile,flags);
		}
log("inside executeCommand check 2");		
		if (c->out != Tnil) /*Handle Output redirection*/
			switch ( c->out ) {
				case Tout:
					flags = O_CREAT | O_WRONLY; /*create if doesn't exist and open write only*/
					redirectOutput(c->outfile,flags);
					break;
				case Tapp:
					flags = O_CREAT | O_WRONLY| O_APPEND; /*create if doesn't exist and open write only and open append*/
					redirectOutput(c->outfile,flags);
					break;
				case ToutErr:
					flags = O_CREAT | O_WRONLY; /*create if doesn't exist and open write only*/
					redirectOutputError(c->outfile,flags);
					break;
				case TappErr:
					flags = O_CREAT | O_WRONLY | O_APPEND; /*create if doesn't exist and open write only and open append*/
					redirectOutputError(c->outfile,flags);
					break;
				case Tpipe:
					close(pipeFD[0]);
					if(dup2(pipeFD[1],STDOUT_FILENO) == -1){
						log("dup2 failed in Tpipe");
						perror("dup2 Fail");
						exit(-1);
					}
					close(pipeFD[1]);
					break;
				case TpipeErr:
					close(pipeFD[0]);
					if(dup2(pipeFD[1],STDOUT_FILENO) == -1){
						log("dup2 failed in TpipeErr");
						perror("dup2 Fail");
						exit(-1);
					}
					if(dup2(pipeFD[1],STDERR_FILENO) == -1){
						log("dup2 failed in TpipeErr");
						perror("dup2 Fail");
						exit(-1);
					}
					close(pipeFD[1]);
					break;
				default:
					perror("Redirection Token undefined");
					log("ExecuteCommand default condition on token checking");
					exit(EXIT_FAILURE);
			}
			
		if(execvp(c->args[0],c->args) == -1) { /*Execute command c. If successful process should end here*/
			perror("Command not found");
			exit(0);}
	}
}
/*Executes last commmand of pipe*/
void pipeEnd(Cmd c, int readPipeFD[2]) {
	int forkID,waitStatus;
	log("inside pipeEnd");
	
	close(readPipeFD[1]);
	if (isBuiltIn(c->args[0])) {
		executeBuiltinCommand(c);
		return;
	}
	
	forkID = fork();
	if(forkID < 0) { 
		log("last fork failed");
		perror("Fork Error");
		return;
	}
	else if (forkID == 0) { /*forked child execution*/
		log("forking to child");
		signal(SIGINT,SIG_DFL); /*Handle Ctrl C*/
		dup2(readPipeFD[0],STDIN_FILENO);
        close(readPipeFD[0]);
        executeCommand(c,readPipeFD);
		/*shouldn't get back here since child executes and ends the process*/
		log("How did you get here");
		exit(EXIT_FAILURE);
	}
	else { /*forked parent execution*/
		log("forking to parent");
		
		close(readPipeFD[0]);
		/*wait for child to end fix wait()*/
		/*This usage of waitpid was obtained from an online resource as mentioned in references*/
		do {
			waitpid(forkID, &waitStatus, WUNTRACED);
        } while (!WIFEXITED(waitStatus) && !WIFSIGNALED(waitStatus));
	}
}

/*Executes commmands in the middle of pipe*/
void pipeThrough(Cmd c,int readPipeFD[2]) {
	int writePipeFD[2];
	int forkID,waitStatus;
	log("inside pipeThrough");
    
	/*open up a pipe for output*/
	if(pipe(writePipeFD) < 0) {
		log("Pipe Failure");
		perror("Pipe Failure");
		exit(EXIT_FAILURE);
	}
	close(readPipeFD[1]); /*input of input pipe closed*/
	
    forkID = fork();
	if(forkID < 0) { 
		log("fork failed");
		perror("Fork Error");
		return;
	}
	else if (forkID == 0) { /*forked child execution*/
		log("forking to child");
		signal(SIGINT,SIG_DFL); /*Handle Ctrl C*/
		close(writePipeFD[0]);
		dup2(readPipeFD[0],STDIN_FILENO);
        close(readPipeFD[0]);
        executeCommand(c,writePipeFD);
		/*shouldn't get back here since child executes and ends the process*/
		log("How did you get here");
		exit(EXIT_FAILURE);
	}
	else { /*forked parent execution*/
		log("forking to parent");
		
		close(readPipeFD[0]);
		/*wait for child to end fix wait()*/
		/*This usage of waitpid was obtained from an online resource as mentioned in references*/
		do {
			waitpid(forkID, &waitStatus, WUNTRACED);
        } while (!WIFEXITED(waitStatus) && !WIFSIGNALED(waitStatus));
		
		c = c->next;
		if(c) {
			if (c->next != NULL) /*more pipes to go*/
				pipeThrough(c,writePipeFD);
			else /*end of the pipe*/
				pipeEnd(c,writePipeFD);
		}
	}
}

int executePipe(Pipe p) {
	Cmd c;
	int status,forkID,waitStatus;
	int pipeFD[2];
	
	log("inside executePipe");
	status = 0;
	if(p == NULL) /*empty pipe condition*/
		return status;
	/*get the first commmand from the pipe*/
	c = p->head;
	if(c == NULL)
		return 0;
	/*Builtin command as the first and only command in pipe
	* Execute it and leave, no new shell
	*/
	if((c->next == NULL) && (isBuiltIn(c->args[0]))) {
		executeBuiltinCommand(c);
		return status;
	}
	/*If pipe has more than one command create "pipe"*/
	if(c->next != NULL) {
		if(pipe(pipeFD) < 0) {
			perror("Pipe Failure");
			exit(EXIT_FAILURE);
		}
	}

	/*forking a new process here*/
	forkID = fork();
	if(forkID < 0) { 
		perror("Fork Error");
		status = 1;
	}
	else if (forkID == 0) { /*forked child execution*/
		log("forking to child");
		signal(SIGINT,SIG_DFL); /*Handle Ctrl C*/
		executeCommand(c,pipeFD);
		/*shouldn't get back here since child executes and ends the process*/
		log("How did you get here");
		exit(EXIT_FAILURE);
	}
	else { /*forked parent execution*/
		log("forking to parent");
		
		/*wait for child to end fix wait()*/
		/*This usage of waitpid was obtained from an online resource as mentioned in references*/
		do {
			waitpid(forkID, &waitStatus, WUNTRACED);
        } while (!WIFEXITED(waitStatus) && !WIFSIGNALED(waitStatus));
		
		c = c->next;
		if(c) {
			if (c->next != NULL) /*more pipes to go*/
				pipeThrough(c,pipeFD);
			else /*end of the pipe*/
				pipeEnd(c,pipeFD);
		}
	}
		
	if(status != 0)
		log("check something here");
	return status;
}


int main() {
	int status;
	Pipe p;
	char hostName[100];
	int backup_InFD,backup_OutFD,backup_ErrFD;
	
	status = 1;
	log("inside main");
	/*Ignore most common signals*/
	signal(SIGQUIT,SIG_IGN);
	signal(SIGTSTP,SIG_IGN);
	signal(SIGSTOP,SIG_IGN);
	signal(SIGINT,SIG_IGN);
	/*getting host name and assigning to prompt*/
	if(gethostname(hostName,sizeof(hostName)) != 0) {
		printf("Get host name failed; Using default host name\n");
		sprintf(hostName,"ush_prompt");
	}
	
	/*handle .ushrc*/
	
	int rcFD;
	char *rcName = strdup(getenv("HOME"));
	strcat(rcName,"/.ushrc");
	if(access(rcName,F_OK) != -1){
		rcFD = open(rcName, O_RDONLY);
		if(rcFD < 0){
			printf("Could not open .ushrc\n");
		}
		else {
			backup_InFD = dup(STDIN_FILENO);
			backup_OutFD = dup(STDOUT_FILENO);
			backup_ErrFD = dup(STDERR_FILENO); /*saving the STD streams to backup*/
			dup2(rcFD,STDIN_FILENO);
			do {
				p = parse();
				if(p==NULL)
					break;
				if (!strcmp(p->head->args[0], "end"))
					break;
				executePipe(p);
				freePipe(p);
			} while (1);
			freePipe(p);
			close(rcFD);
			dup2(backup_InFD,STDIN_FILENO); /*restoring the STD streams*/
			dup2(backup_OutFD,STDOUT_FILENO);
			dup2(backup_ErrFD,STDERR_FILENO);
		}
	}
	fflush(stdout);
	
	/*Start of execution*/
	while ( status ) {
		backup_InFD = dup(STDIN_FILENO);/*saving the STD streams to backup*/
		backup_OutFD = dup(STDOUT_FILENO);
		backup_ErrFD = dup(STDERR_FILENO);
		log("inside main loop");
		
		/*check whether you are getting input from file or STDIN*/
		/*stack overflow fix*/
		if (isatty(STDIN_FILENO)) {
            printf("%s$ ",hostName);
            fflush(stdout);            
        }
		
		p = parse(); /*Invoke parser*/
		while((p!= NULL)&&(status > 0)){
			if (p != NULL) {
				if (!strcmp((p->head)->args[0], "end")){
					if (isatty(STDIN_FILENO)) { /*stack overflow fix*/
						printf("\n");
					}
					freePipe(p);
					exit(EXIT_SUCCESS);
				}
			}
			status = status - executePipe(p);
			p = p->next;
			if(status == 0)
				log("check something here");
		}
		freePipe(p);
		dup2(backup_InFD,STDIN_FILENO); /*restoring the STD streams*/
		dup2(backup_OutFD,STDOUT_FILENO);
		dup2(backup_ErrFD,STDERR_FILENO);
	}
	return 0;
}