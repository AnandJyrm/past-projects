/*CSC 501 Operating Systems Programming Assignment P3
* Hot Potato game using TCP/IP socket programming
* Anand Jayaram
* base.c 
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

int send_to(char * buff, int len, int socket) {
	int sentLen,tot;
	do {
		sentLen = send(socket, buff, len, 0);
		if(sentLen < 0)
			fprintf(stderr, "send failed.\n");
			break;
		len = len - sentLen;
		buff = buff + sentLen;
		tot = tot + sentLen;
	} while(len != 0);
	return sentLen;
}

unsigned long listen_from(char *buff, int socket) {
	long len;
	unsigned long tot = 0;
    do{
		len = recv(socket, buff, 500, 0);
		tot = tot + len;
		if(len < 0){
			fprintf(stderr, "recv failed.\n");
			tot = -1;
			break;
		}
		if(buff[len-1] == '\0')
			break;
		else{
			buff = buff + len;
		}

	}while(len != 0);
	return tot;
}
int create_listening_socket(struct sockaddr_in Addr){
	int sock, addrLen, optval;
	socklen_t optlen;
	optval = 1;
	optlen = sizeof(optval);
	addrLen = sizeof(Addr);
	sock = socket(AF_INET,SOCK_STREAM, 0);
	if(sock < 0) {
		fprintf(stderr, "socket syscall failed.\n");
		exit(EXIT_FAILURE);
	}
	if(setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &optval, optlen) < 0){
		fprintf(stderr, "setsockopt failed.\n");
	}
	if(bind(sock, (struct sockaddr *)&Addr, addrLen) < 0) {
		fprintf(stderr, "bind syscall failed.\n");
		exit(EXIT_FAILURE);
	}
	if (listen(sock, 1) < 0) {
		fprintf(stderr, "listen syscall failed.\n");
		exit(EXIT_FAILURE);
	}
	return sock;
}

void add_int_to_message(char *message, int i){
	char *buff;
	buff = (char *)malloc(sizeof(char)*10);
	memset((void *)buff,'\0',10);
	sprintf(buff,"%d",i);
	strcat(message,buff);
	free(buff);
}