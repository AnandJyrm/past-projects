/*CSC 501 Operating Systems Programming Assignment P3
* Hot Potato game using TCP/IP socket programming
* Anand Jayaram
* base.h
*/

int send_to(char * buff, int len, int socket);

unsigned long listen_from(char *buff, int socket);

int create_listening_socket(struct sockaddr_in Addr);

void add_int_to_message(char *message, int i);