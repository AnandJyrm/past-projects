/*CSC 501 Operating Systems Programming Assignment P3
* Hot Potato game using TCP/IP socket programming
* Anand Jayaram
* master.c
* dependencies: base.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h> 
#include "base.h"

int main(int argc, char *argv[]) {
	
	char hostName[100],playerName[100];
	char *message, *buff;
	struct hostent *hostAddress;
	struct sockaddr_in master_sockaddr, *player_sockaddr;
	int portNumber, nofPlayers, hops, i, j, check, firstPick, addrLen, sock, *sockArray, *playerListeningPort, messType, len, nfds;

	fd_set socket_fd_set;
	struct timeval tOut;
	tOut.tv_sec = 1000;
	tOut.tv_usec = 0;

	
	srand(time(NULL));
	/*************************************************************************************************************************************
	*Input Sanitization
	*************************************************************************************************************************************/
	if(argc < 4) {
		fprintf(stderr, "Usage: %s <port-number> <number-of-players> <hops>\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	portNumber = atoi(argv[1]);
	nofPlayers = atoi(argv[2]);
	hops = atoi(argv[3]);
	if(nofPlayers < 1) {
		fprintf(stderr, "Number of players should be greater than 1.\n");
		exit(EXIT_FAILURE);
	}
	if(portNumber < 1024) {
		fprintf(stderr, "Can't use reserved ports.\n");
		exit(EXIT_FAILURE);
	}
	if(hops < 0) {
		fprintf(stderr, "Positve hop numbers only.\n");
		exit(EXIT_FAILURE);
	}
	
	/*************************************************************************************************************************************
	*Getting master host name
	*************************************************************************************************************************************/
	memset(hostName, '\0', 100);
	if(gethostname(hostName, sizeof(hostName)) < 0)
		sprintf(hostName,"Host_Name_unknown");
	hostAddress = gethostbyname(hostName);
	if(hostAddress == NULL ) {
		fprintf(stderr, "gethostbyname failed.\n");
		exit(EXIT_FAILURE);
	}

	/*************************************************************************************************************************************
	*Initial output
	*************************************************************************************************************************************/
	printf("\nPotato Master on %s \n", hostName);
    printf("Players = %d \n", nofPlayers);
	printf("Hops = %d \n\n", hops);
	
	/*************************************************************************************************************************************
	*Creating the listening socket for players to connect
	*************************************************************************************************************************************/
	memset(&master_sockaddr, 0, sizeof(master_sockaddr));
	master_sockaddr.sin_family = AF_INET;
	master_sockaddr.sin_port = htons(portNumber);
	memcpy(&master_sockaddr.sin_addr, hostAddress->h_addr_list[0], hostAddress->h_length);
	addrLen = sizeof(master_sockaddr);
	sockArray = (int *)malloc(sizeof(int)*nofPlayers); /*Array for storing player sockets*/
	playerListeningPort =(int *)malloc(sizeof(int)*nofPlayers); /*Array for storing players' listening port*/
	player_sockaddr = (struct sockaddr_in*)malloc(sizeof(struct sockaddr_in)*nofPlayers); /*Array for storing players socket address*/
    sock = create_listening_socket(master_sockaddr);
		
	/*************************************************************************************************************************************
	*Add the listen socket to select list for timeout feature
	*************************************************************************************************************************************/
	FD_ZERO(&socket_fd_set);
	FD_SET(sock, &socket_fd_set);
	nfds = FD_SETSIZE;
	for (i = 0; i < nofPlayers; i++) {
		check = select (nfds, &socket_fd_set, NULL, NULL, &tOut); /* wait till tOut for each player connection.*/
		if ( check < 0) {
			fprintf(stderr, "select failed.\n");
			exit (EXIT_FAILURE);
        }
		else if (check == 0) {
			fprintf(stderr, "players failed to connect in time.\n");
			exit(EXIT_FAILURE);
		}
		else {
			/*accept connection from each player*/
			sockArray[i] = accept(sock, (struct sockaddr *)&player_sockaddr[i], (socklen_t *)&addrLen);
			if (sockArray[i] < 0) {
				fprintf(stderr, "accept failed.\n");
				exit (EXIT_FAILURE);
			}
			/*accept each player's listening port and hostname*/
			message = (char *)malloc(sizeof(char)*150);
			memset((void *)message, '\0', 150);
			check = listen_from(message, sockArray[i]);
			if (check <= 0) {
				fprintf(stderr, "Error in listening function.\n");
				exit(EXIT_FAILURE);
			}
			/*extract the player info and store it*/
			memset(playerName,'\0',100);
			sscanf(message, "%d\t%d\t%s", &messType, &playerListeningPort[i], playerName);
			printf("player <%d> is on %s.\n", i, playerName);
			free(message);
		}
    }
	/*************************************************************************************************************************************
	*Sending neighbour info to each player
	*************************************************************************************************************************************/
	for (i = 0; i < nofPlayers; i++) {
		message = (char *)malloc(sizeof(char)*100);
		memset((void *)message,'\0',100);
		strcat(message,"1\t");
		add_int_to_message(message, i);
		strcat(message,"\t");
		j = i +1;
		if (j == nofPlayers)
			j = 0;
		strcat(message, inet_ntoa(player_sockaddr[j].sin_addr));
		strcat(message, "\t");
		add_int_to_message(message, playerListeningPort[j]);
		strcat(message, "\t");
		add_int_to_message(message, nofPlayers);
		len = strlen(message) + 1;
		check = send_to(message, len, sockArray[i]);
		if(check < 0)
			fprintf(stderr, "Error in send function.\n");
		free(message);
    }
	sleep(2);
	/*************************************************************************************************************************************
	*If hops > 0 start game
	*************************************************************************************************************************************/
	if(hops > 0) {
		message = (char *)malloc(sizeof(char)*500); /*create potato*/
		memset((void *)message,'\0',500);
		strcat(message,"3\t");
		add_int_to_message(message, hops);
		len = strlen(message) + 1;
		
		/*pick the first player to get potato*/
		firstPick = (rand() % nofPlayers);
		check = send_to(message, len, sockArray[firstPick]); /*send potato*/
		printf("\nAll players present, sending potato to player <%d>\n\n", firstPick);
		free(message);
		if (check <= 0 ) {
			fprintf(stderr, "Error in send function.\n");
			exit(EXIT_FAILURE);
		}
		
		/*************************************************************************************************************************************
		* Create select set to listen from all players
		*************************************************************************************************************************************/
		FD_ZERO(&socket_fd_set);
		for (i = 0; i < nofPlayers; i++) {
			FD_SET(sockArray[i], &socket_fd_set);
		}
		nfds = FD_SETSIZE;
		check = select (nfds, &socket_fd_set, NULL, NULL, NULL);
		if ( check < 0) {
			fprintf(stderr, "select failed.\n");
			exit (EXIT_FAILURE);
		}
		for (i = 0; i < nofPlayers; i++) {
			if(FD_ISSET(sockArray[i], &socket_fd_set)) {
				message = (char *)malloc(sizeof(char)*1000000);
				memset((void *)message, '\0', 1000000);
				check = listen_from(message, sockArray[i]); /*get potato back from player*/
				if (check <= 0) {
					fprintf(stderr, "Error in listen function.\n");
					exit(EXIT_FAILURE);
				}
				break;
			}
		}
		/*extract trace from potato*/
		buff = (char *)malloc(sizeof(char)*1000000);
		memset((void *)buff, '\0', 1000000);
		sscanf(message, "%*d\t%*d\t%s", buff);
		printf("Trace:\n%s\n\n",buff); /*print trace*/
		free(buff);
		free(message);
	}
	/*************************************************************************************************************************************
	*Send terminate message to all players
	*************************************************************************************************************************************/
	for(i = 0; i < nofPlayers; i++) {
		message = (char *)malloc(sizeof(char)*10);
		memset((void *)message,'\0',10);
		strcat(message,"4\tbye");
		len = strlen(message) + 1;
		check = send_to(message,len, sockArray[i]);
		if (check <= 0) {
			fprintf(stderr, "Error in send function.\n");
			exit(EXIT_FAILURE);
		}
		free(message);
	}

	/*************************************************************************************************************************************
	*close all sockets
	*************************************************************************************************************************************/
	close(sock);
	for (i = 0; i < nofPlayers; i++)
		close(sockArray[i]);
	
	return 0;
}