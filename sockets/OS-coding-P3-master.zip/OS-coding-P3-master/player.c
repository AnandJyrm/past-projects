/*CSC 501 Operating Systems Programming Assignment P3
* Hot Potato game using TCP/IP socket programming
* Anand Jayaram
* player.c
* dependencies: base.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>
#include "base.h"

int main(int argc, char * argv[]) {
	struct hostent *master_hostent, *hostAddress;
	int portNumber, listeningPort, playerNumber, nofPlayers, check, len, choice, addrLen;
	int messType, rightport, listenSocket, rightSocket, leftSocket, masterSocket, hop, nfds;
	char hostName[100], rightString[20], *message, *buff; 
	struct sockaddr_in left, right,master_sockaddr;
	fd_set socket_fd_set;
	
	srand(time(NULL));
	/*************************************************************************************************************************************
	*Input Sanitization
	*************************************************************************************************************************************/
	if(argc < 3) {
		fprintf(stderr, "Usage: %s <master-machine-name> <port-number>\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	master_hostent = gethostbyname(argv[1]);
	if(master_hostent == NULL) {
		fprintf(stderr, "%s: host not found (%s)\n", argv[0], argv[1]);
		exit(EXIT_FAILURE);
	}
	portNumber = atoi(argv[2]);
	if(portNumber < 1024) {
		fprintf(stderr, "Can't use reserved ports.\n");
		exit(EXIT_FAILURE);
	}
	
	
	/*************************************************************************************************************************************
	*Creating master Socket
	*************************************************************************************************************************************/
	masterSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(masterSocket < 0) {
		fprintf(stderr, "socket failed.\n");
		exit(EXIT_FAILURE);
	}	
	memset(&master_sockaddr, 0, sizeof(master_sockaddr));
	master_sockaddr.sin_family = AF_INET;
	master_sockaddr.sin_port = htons(portNumber);
	memcpy(&master_sockaddr.sin_addr, master_hostent->h_addr_list[0], master_hostent->h_length);
	addrLen = sizeof(master_sockaddr);
	
	/*************************************************************************************************************************************
	*Connect to master socket
	*************************************************************************************************************************************/
	if ( connect(masterSocket, (struct sockaddr *)&master_sockaddr, addrLen) < 0 ) {
		fprintf(stderr, "connect failed.\n");
		exit(EXIT_FAILURE);
	}
	
	/*************************************************************************************************************************************
	*Open a listening Socket 
	*************************************************************************************************************************************/
	listenSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(listenSocket < 0) {
		fprintf(stderr, "socket failed.\n");
		exit(EXIT_FAILURE);
	}
	
	memset(&left, 0, addrLen);
	left.sin_family = AF_INET;
	if( gethostname(hostName, sizeof(hostName)) < 0)
		sprintf(hostName,"Host_Name_unknown");

	hostAddress = gethostbyname(hostName);
	if ( hostAddress == NULL ) {
		fprintf(stderr, "gethostbyname failure.\n");
		exit(EXIT_FAILURE);
	}
	memcpy(&left.sin_addr, hostAddress->h_addr_list[0], hostAddress->h_length);
	
	/*************************************************************************************************************************************
	*Iterate on bind till it works
	*************************************************************************************************************************************/
	do{
		listeningPort = portNumber + (rand() % 2000); 
		left.sin_port = htons(listeningPort);
		check = bind(listenSocket, (struct sockaddr *)&left, addrLen);
	} while(check < 0);
	
	/*************************************************************************************************************************************
	*Create message with format "2\t<port number>\t<hostname>" and send it to master
	*************************************************************************************************************************************/
	message = (char *)malloc(sizeof(char)*100);
	memset((void *)message,'\0',100);
	strcat(message,"2\t");
	buff = (char *)malloc(sizeof(char)*20);
	memset((void *)buff,'\0',20);
	sprintf(buff,"%d\t",listeningPort);
	strcat(message,buff);
	strcat(message,hostName);
	len = strlen(message)+1;
	send_to(message, len, masterSocket);
	free(message);
	free(buff);
	
	/*************************************************************************************************************************************
	*Recieve neighbour info from master
	*************************************************************************************************************************************/
	buff = (char *)malloc(sizeof(char)*500);
	memset((void *)buff,'\0',500);
	check = listen_from(buff,masterSocket);
	
	if(check <= 0) {
		fprintf(stderr, "listen function failed.\n");
		exit(EXIT_FAILURE);
	}
	
	memset((void *)rightString,'\0',20);
	sscanf(buff,"%d\t%d\t%s\t%d\t%d",&messType,&playerNumber,rightString,&rightport,&nofPlayers);
	if(messType != 1){
		fprintf(stderr, "invalid message type.\n");
		exit(EXIT_FAILURE);
	}
	printf("\nConnected as player <%d>\n\n",playerNumber);

	/*************************************************************************************************************************************
	*Start listening
	*************************************************************************************************************************************/
	if(listen(listenSocket, 5) < 0) {
		fprintf(stderr, "listen failed.\n");
	}

	rightSocket = socket(AF_INET,SOCK_STREAM,0);
	memset(&right, 0, addrLen);
	right.sin_family = AF_INET;
	right.sin_port = htons(rightport);
	inet_aton(rightString,&right.sin_addr);
	
	/*************************************************************************************************************************************
	*Connect to neighbour in deadlock resolving manner: player 0 connects and then accepts. rest of the players accept and then connect
	*************************************************************************************************************************************/
	sleep(2);
	if(playerNumber == 0) {
		sleep(1);
		if(connect(rightSocket, (struct sockaddr *)&right, addrLen) < 0) { /*connect*/
			fprintf(stderr, "connect to peer failed.\n");
			exit(EXIT_FAILURE);
		}
		
		leftSocket = accept(listenSocket, (struct sockaddr *)&left, (socklen_t *)&addrLen); /*accept*/
		if(leftSocket < 0)
			fprintf(stderr, "accept failed.\n");
	} else {
		leftSocket = accept(listenSocket, (struct sockaddr *)&left, (socklen_t *)&addrLen); /*accept*/
		if(leftSocket < 0)
			fprintf(stderr, "accept failed.\n");
		
		if(connect(rightSocket, (struct sockaddr *)&right, addrLen) < 0) { /*connect*/
			fprintf(stderr, "connect to peer failed.\n");
			exit(EXIT_FAILURE);
		}
	}

	/*************************************************************************************************************************************
	*Listen and process potato till shutdown/hop becomes 0
	*************************************************************************************************************************************/
	while(1) {
		/*************************************************************************************************************************************
		*Add the three sockets to  select list
		*************************************************************************************************************************************/
		FD_ZERO(&socket_fd_set);
		FD_SET(masterSocket, &socket_fd_set);
		FD_SET(leftSocket, &socket_fd_set);
		FD_SET(rightSocket, &socket_fd_set);
		nfds = FD_SETSIZE;
		check = select(nfds, &socket_fd_set, NULL, NULL, NULL);
		if(check < 0) {
			fprintf(stderr, "select failed.\n");
			exit (EXIT_FAILURE);
		}
		message = (char *)malloc(sizeof(char)*1000000);
		memset((void *)message,'\0',1000000);
		
		/*************************************************************************************************************************************
		*If masterSocket was set, read from master
		*************************************************************************************************************************************/
		if(FD_ISSET(masterSocket, &socket_fd_set)) {
			listen_from(message, masterSocket);
			FD_CLR(masterSocket, &socket_fd_set);
		} else 
		/*************************************************************************************************************************************
		*If leftSocket was set, read from left
		*************************************************************************************************************************************/
		if(FD_ISSET(leftSocket, &socket_fd_set)) {
			listen_from(message, leftSocket);
			FD_CLR(leftSocket, &socket_fd_set);
		} else 
		/*************************************************************************************************************************************
		*If rightSocket was set, read from right
		*************************************************************************************************************************************/
		if(FD_ISSET(rightSocket, &socket_fd_set)) {
			listen_from(message, rightSocket);
			FD_CLR(rightSocket, &socket_fd_set);
		}
		
		
		/*************************************************************************************************************************************
		*Process message potato
		*************************************************************************************************************************************/
		buff = (char *)malloc(sizeof(char)*1000000);
		memset((void *)buff,'\0',1000000);
		sscanf(message, "%d\t%d\t%s", &messType, &hop, buff);
		if(messType == 3) {
			hop = hop - 1;
			free(message);
			/*create new potato message*/
			message = (char *)malloc(sizeof(char)*1000000);
			memset((void *)message,'\0',1000000);
			strcat(message,"3\t");
			add_int_to_message(message, hop);
			strcat(message,"\t");
			strcat(message,buff); /*append the trace to the potato message*/
			free(buff);
			/*hop > 0 implies send to left or right socket*/
			if(hop > 0) {
				strcat(message,"<");
				add_int_to_message(message, playerNumber); /*append the current player number to trace*/
				strcat(message, ">, "); 
				len = strlen(message)+1;
				choice = (rand() % 2);
				if(choice == 0) {
					check = send_to(message, len, leftSocket);
					printf("Sending potato to <%d>\n", (playerNumber == 0)?(nofPlayers-1):(playerNumber-1));
				}					
				else {
					check = send_to(message, len, rightSocket);
					printf("Sending potato to <%d>\n", (playerNumber == (nofPlayers-1))?0:(playerNumber+1));

				}
			} else { /*hop  = 0 implies send to master socket*/
				strcat(message,"<");
				add_int_to_message(message, playerNumber); /*append the current player number to trace*/
				strcat(message, ">"); 
				len = strlen(message)+1;
				check = send_to(message,len,masterSocket);
				printf("\nI'm it.\n");
			}
			free(message);
		} else if(messType == 4) {
			free(message);
			free(buff);
			close(masterSocket);
			close(leftSocket);
			close(rightSocket);
			close(listenSocket);
			exit(EXIT_SUCCESS);
		}
	}
	close(masterSocket);
	close(leftSocket);
	close(rightSocket);
	close(listenSocket);
	return 0;
}