# OS-coding-P3
Use sockets and TCP/IP communication to play a distributed game of "hot potato." 
