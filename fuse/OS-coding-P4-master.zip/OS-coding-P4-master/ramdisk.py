#!/usr/bin/env python
#CSC501 P4 RAMDISK
#submitted by Anand Jayaram

from __future__ import print_function, absolute_import, division 

import pickle
import os.path

from collections import defaultdict
from errno import ENOENT, ENOSPC, ENOTEMPTY
from stat import S_IFDIR, S_IFLNK, S_IFREG
from sys import argv, exit, getsizeof
from time import time

from fuse import FUSE, FuseOSError, Operations


if not hasattr(__builtins__, 'bytes'): 
    bytes = str

MemInUse = 0 # size of data
AllocatedMem = 0 # given size of file system
PersistFile = None # store the persistent file for extra credit

class Ramdisk(Operations): 
    """In Memory File System using FUSE. Has a flat file structure which mimics directory commands"""
    
    def sizeFAT(self):
        """helper function to return size of FAT"""
        size = 0
        for x in self.FAT:
            size = size + getsizeof(x)
            for y in self.FAT[x]:
                size = size + getsizeof(y) + getsizeof(self.FAT[x][y])
        return size

    def sizedata(self):
        """helper function to return size of data"""
        size = 0
        for x in self.data:
            size = size + getsizeof(self.data[x])
        return size
        
    def __init__(self):
        """Initialize the table of files"""
        global MemInUse, AllocatedMem, PersistFile
        self.FAT = {}
        self.data = defaultdict(bytes)
        self.fd = 0
        now = time()
        if os.path.isfile(str(PersistFile)):
            f = open(PersistFile, 'r')
            obj = pickle.load(f)
            [self.FAT, self.data, self.fd] = obj
            f.close()
        else:
            self.FAT['/'] = dict(st_mode=(S_IFDIR | 0o755), st_ctime=now, st_mtime=now, st_atime=now, st_nlink=2)
        MemInUse = self.sizeFAT() + self.sizedata()

    def create(self, path, mode):
        """add an entry to table of files and return file descriptor count"""
        global MemInUse
        self.FAT[path] = dict(st_mode=(S_IFREG | mode), st_nlink=1, st_size=0, st_ctime=time(), st_mtime=time(), st_atime=time())
        self.fd += 1
        for x in self.FAT[path]:
            MemInUse = MemInUse + getsizeof(x) + getsizeof(self.FAT[path][x])
        return self.fd

    def getattr(self, path, fh=None):
        """Return attributes from table of files"""
        if path not in self.FAT:
            raise FuseOSError(ENOENT)
        return self.FAT[path]

    def mkdir(self, path, mode):
        """create entry in table of files"""
        global MemInUse
        self.FAT[path] = dict(st_mode=(S_IFDIR | mode), st_nlink=2, st_size=0, st_ctime=time(), st_mtime=time(), st_atime=time())
        self.FAT['/']['st_nlink'] += 1
        for x in self.FAT[path]:
            MemInUse = MemInUse + getsizeof(x) + getsizeof(self.FAT[path][x])
                
    def open(self, path, flags):
        """Create an entry to table of files if file doesn't exist"""
        self.fd += 1
        return self.fd

    def read(self, path, size, offset, fh):
        """Read from file data at offset"""
        return self.data[path][offset:offset + size]

    def readdir(self, path, fh):
        """return list of files"""
        dirList = []
        if path == '/':
            dirList = [x[len(path):].split('/')[0] for x in self.FAT if x.startswith(path) and x != '/']
        else:
            dirList = [x[len(path):].split('/')[0] for x in self.FAT if x.startswith(path + '/')]
        dirList = ['.', '..'] + list(set(dirList))
        return dirList

    def rename(self, old, new):
        """rename key in table of files"""
        self.FAT[new] = self.FAT.pop(old)

    def rmdir(self, path):
        """remove path from table of files"""
        if self.readdir(path, None) == ['.','..']:
            global MemInUse
            for x in self.FAT[path]:
                MemInUse = MemInUse - getsizeof(x) - getsizeof(self.FAT[path][x])
            self.FAT.pop(path)
            self.FAT['/']['st_nlink'] -= 1
        else:
            raise FuseOSError(ENOTEMPTY)

    def truncate(self, path, length, fh=None):
        """empty file for size length"""
        global MemInUse
        MemInUse = MemInUse - self.FAT[path]['st_size'] + length
        self.data[path] = self.data[path][:length]
        self.FAT[path]['st_size'] = length
        
    def unlink(self, path):
        """remove from path"""
        global MemInUse
        for x in self.FAT[path]:
            MemInUse = MemInUse - getsizeof(x) - getsizeof(self.FAT[path][x])
        self.FAT.pop(path)
    
    def statfs(self, path):
        """size of file system"""
        global AllocatedMem, MemInUse
        tot = int(AllocatedMem / 512)
        free = tot - int(MemInUse / 512)
        return dict(f_bsize=512, f_frsize=512, f_blocks=tot, f_bfree=free, f_bavail=free)
                         
    def utimens(self, path, times=None):
        """update time"""
        now = time()
        atime, mtime = times if times else (now, now)
        self.FAT[path]['st_atime'] = atime
        self.FAT[path]['st_mtime'] = mtime
        
    def write(self, path, data, offset, fh):
        """update the file data at offset"""
        global MemInUse, AllocatedMem
        if (MemInUse + getsizeof(data)) > AllocatedMem:
            raise FuseOSError(ENOSPC)
        else:
            self.data[path] = self.data[path][:offset] + data
            self.FAT[path]['st_size'] = getsizeof(self.data[path])
            MemInUse = MemInUse + getsizeof(data)
        return getsizeof(data)

    def destroy(self, path):
        """function callled on unmount"""
        if len(argv) == 4:
            global PersistFile
            obj = [self.FAT, self.data, self.fd]
            f = open(PersistFile, 'w')
            pickle.dump(obj,f)
            f.close()

if __name__ == '__main__':
    """main function: start of execution"""
    if len(argv) > 4 or len(argv) < 3: #check inputs
        print("usage: %s <mountpoint> <size> [<filename>]" % argv[0])
        exit('usage error')
    try:
        AllocatedMem = int(argv[2]) * 1024 * 1024
    except ValueError:
        print("usage: %s <mountpoint> <size> [<filename>]" % argv[0])
        exit('usage error')
    if len(argv) == 4:
        PersistFile = argv[3]
    fuse = FUSE(Ramdisk(), argv[1], foreground=False)
