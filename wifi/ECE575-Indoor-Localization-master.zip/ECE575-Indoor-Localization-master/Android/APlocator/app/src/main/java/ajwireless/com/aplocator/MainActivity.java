package ajwireless.com.aplocator;

import android.content.BroadcastReceiver;
import android.support.design.widget.FloatingActionButton;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Collections;
import java.util.Comparator;


public class MainActivity extends AppCompatActivity {
    //Wifi libraries
    WifiManager wifi;
    BroadcastReceiver wifiDataReceiver = null;
    public Timer timerScanAPs;
    boolean shouldScan = false;
    public String AP_Names[] = {"AP 3044","AP 3059","AP 3028","AP 3102","AP 3001","AP 3002","AP 3309","AP 3218","AP 3265","AP 3234"};
    public int AP_no = 10;
    public String AP_BSSID1[] = {"24:de:c6:e1:29:6","d8:c7:c8:38:22:c","d8:c7:c8:38:22:6","d8:c7:c8:38:1d:a","d8:c7:c8:38:19:2","d8:c7:c8:38:30:4","d8:c7:c8:38:1c:6","d8:c7:c8:38:2b:y","d8:c7:c8:38:1f:6","d8:c7:c8:38:2f:8"};
    public String AP_BSSID2[] = {"24:de:c6:e1:29:7","d8:c7:c8:38:22:d","d8:c7:c8:38:22:7","d8:c7:c8:38:1d:b","d8:c7:c8:38:19:3","d8:c7:c8:38:30:5","d8:c7:c8:38:1c:7","d8:c7:c8:38:2b:y","d8:c7:c8:38:1f:7","d8:c7:c8:38:2f:9"};
    public int Measured_RSSI[]={0,0,0,0,0,0,0,0,0,0};
    public int no_BSSID[] = {0,0,0,0,0,0,0,0,0,0};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Enable WiFi
        wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        if (!wifi.isWifiEnabled())
        {
            Toast.makeText(getApplicationContext(), "wifi is disabled..making it enabled", Toast.LENGTH_LONG).show();
            wifi.setWifiEnabled(true);
        }
        wifiDataReceiver = new WifiScanReceiver();
        // register to receive the WiFi updates
        registerReceiver(wifiDataReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

        timerScanAPs = new Timer();	//timer to periodically update the location
        timerScanAPs.scheduleAtFixedRate(new ScanAPsTask(), 1000, 50000);

        TextView text = (TextView) findViewById(R.id.rssi);
        text.setText("AP --> RSSI values here!");

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new ScanAPsTask().run();
            }
        });
    }

    class ScanAPsTask extends TimerTask {
        @Override
        public void run() {
            shouldScan = true;
            if(!wifi.startScan()){
                Toast.makeText(getApplicationContext(), "Wifi Scan Error", Toast.LENGTH_LONG).show();
                //bad - might want error correction
            }
        }
    }

    // Register to get the Signal Strengths
    private class WifiScanReceiver extends BroadcastReceiver{
            // onReceive for the WiFi broadcast signal
            @Override
        public void onReceive(Context c, Intent intent) {
            if (shouldScan) {
                // Scan signal strengths if it is time
                Arrays.fill(no_BSSID, 0);
                Arrays.fill(Measured_RSSI, 0);

                List<ScanResult> results = wifi.getScanResults();
                Collections.sort(results, new Comparator<ScanResult>() {
                    public int compare(ScanResult lhs, ScanResult rhs) {
                        return lhs.level > rhs.level ? -1 : (lhs.level > rhs.level ) ? 1 : 0;
                    }
                });
                for(int i = 0;i < results.size();i++) {
                    ScanResult result = results.get(i);
                    for(int j =0;j < AP_no; j++){
                        if((result.BSSID).startsWith(AP_BSSID1[j])||(result.BSSID).startsWith(AP_BSSID2[j])){
                            Measured_RSSI[j] = Measured_RSSI[j] + result.level;
                            no_BSSID[j]++;
                        }
                    }

                }
                String displayText = "";
                for(int i =0;i < AP_no;i++){
                    if(no_BSSID[i]!=0){
                        Measured_RSSI[i] = Measured_RSSI[i]/no_BSSID[i];
                        displayText = displayText + AP_Names[i] + " --> " + Integer.toString(Measured_RSSI[i]) + "\n";
                    }
                }
                int Max_results = results.size()> 10? 10:results.size();
                for (int i = 0; i < Max_results; i++) {
                    ScanResult result = results.get(i);
                    // Add this signal strength reading as a parameter where the name is the BSSID

                    displayText = displayText + result.BSSID +" --> "+ Integer.toString(result.level) + "\n";
                }
                shouldScan = false;
                TextView text = (TextView) findViewById(R.id.rssi);
                text.setText(displayText);

            }
        }
    }
}