package ncsu.trilateration;

import android.content.BroadcastReceiver;
//import android.support.design.widget.FloatingActionButton;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Collections;
import java.util.Comparator;


public class MainActivity extends AppCompatActivity {
    //Wifi libraries
    WifiManager wifi;
    BroadcastReceiver wifiDataReceiver = null;
    public Timer timerScanAPs;
    boolean shouldScan = false;
    public String AP_Names[] = {"AP 3044","AP 3059","AP 3028","AP 3102","AP 3001","AP 3002","AP 3309","AP 3218","AP 3265","AP 3234"};
    public int AP_no = 10;
    public String AP_BSSID1[] = {"24:de:c6:e1:29:6","d8:c7:c8:38:22:c","d8:c7:c8:38:22:6","d8:c7:c8:38:1d:a","d8:c7:c8:38:19:2","d8:c7:c8:38:30:4","d8:c7:c8:38:1c:6","d8:c7:c8:38:2b:y","d8:c7:c8:38:1f:6","d8:c7:c8:38:2f:8"};
    public String AP_BSSID2[] = {"24:de:c6:e1:29:7","d8:c7:c8:38:22:d","d8:c7:c8:38:22:7","d8:c7:c8:38:1d:b","d8:c7:c8:38:19:3","d8:c7:c8:38:30:5","d8:c7:c8:38:1c:7","d8:c7:c8:38:2b:y","d8:c7:c8:38:1f:7","d8:c7:c8:38:2f:9"};
    public int Measured_RSSI[]={0,0,0,0,0,0,0,0,0,0};
    public int no_BSSID[] = {0,0,0,0,0,0,0,0,0,0};

    int radii[] = {0, 0, 0, 0, 0, 0};
    int AP_XCenter[] = {110, 203, 95, 260, 100, 130};
    int AP_YCenter[] = {585, 545, 350, 235, 60, 95};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Enable WiFi
        wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        if (!wifi.isWifiEnabled())
        {
            Toast.makeText(getApplicationContext(), "wifi is disabled..making it enabled", Toast.LENGTH_LONG).show();
            wifi.setWifiEnabled(true);
        }
        wifiDataReceiver = new WifiScanReceiver();
        // register to receive the WiFi updates
        registerReceiver(wifiDataReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

        timerScanAPs = new Timer();	//timer to periodically update the location
        timerScanAPs.scheduleAtFixedRate(new ScanAPsTask(), 1000, 3000);

        TextView text = (TextView) findViewById(R.id.rssi);
        text.setText("AP --> RSSI values here!");
        //drawCircles();
    }

    class ScanAPsTask extends TimerTask {
        @Override
        public void run() {
            shouldScan = true;
            if(!wifi.startScan()){
                Toast.makeText(getApplicationContext(), "Wifi Scan Error", Toast.LENGTH_LONG).show();
                //bad - might want error correction
            }
        }
    }

    // Register to get the Signal Strengths
    private class WifiScanReceiver extends BroadcastReceiver{
        // onReceive for the WiFi broadcast signal
        @Override
        public void onReceive(Context c, Intent intent) {
            if (shouldScan) {
                // Scan signal strengths if it is time

                Arrays.fill(Measured_RSSI, 0);
                Arrays.fill(no_BSSID, 0);
                List<ScanResult> results = wifi.getScanResults();
                Collections.sort(results, new Comparator<ScanResult>() {
                    public int compare(ScanResult lhs, ScanResult rhs) {
                        return lhs.level > rhs.level ? -1 : (lhs.level > rhs.level ) ? 1 : 0;
                    }
                });
                for(int i = 0;i < results.size();i++) {
                    ScanResult result = results.get(i);
                    for(int j =0;j < AP_no; j++){
                        if((result.BSSID).startsWith(AP_BSSID1[j])||(result.BSSID).startsWith(AP_BSSID2[j])){
                            Measured_RSSI[j] = Measured_RSSI[j] + result.level;
                            no_BSSID[j]++;
                        }
                    }
                }
                String displayText = "";
                for(int i =0;i < AP_no;i++){
                    if(no_BSSID[i]!=0){
                        Measured_RSSI[i] = Measured_RSSI[i]/no_BSSID[i];
                        displayText = displayText + AP_Names[i] + " --> " + Integer.toString(Measured_RSSI[i]) + "\n";
                    }
                }
                int Max_results = results.size()> 10? 10:results.size();
                for (int i = 0; i < Max_results; i++) {
                    ScanResult result = results.get(i);
                    // Add this signal strength reading as a parameter where the name is the BSSID
                    //displayText = displayText + result.BSSID +" --> "+ Integer.toString(result.level) + "\n";
                }
                shouldScan = false;
                TextView text = (TextView) findViewById(R.id.rssi);
                text.setText(displayText);
                for(int i = 0; i < Measured_RSSI.length; i++){
                    if(Measured_RSSI[i] == 0) {
                        Measured_RSSI[i] = -100;
                    }
                }
                computeRadii();
                drawCircles();
            }
        }
    }

    public void computeRadii(){
        radii[0] = (int)(2*0.7078*Math.exp(-0.065*(double)Measured_RSSI[0]));
        radii[1] = (int)(2*3.6135*Math.exp(-0.042*(double)Measured_RSSI[1]));
        radii[2] = (int)(2*1.5169*Math.exp(-0.054*(double)Measured_RSSI[2]));
        radii[3] = (int)(2*21.029*Math.exp(-0.018*(double)Measured_RSSI[3]));
        radii[4] = (int)(2*1.0748*Math.exp(-0.058*(double)Measured_RSSI[4]));
        radii[5] = (int)(2*2.224*Math.exp(-0.05*(double)Measured_RSSI[5]));
    }

    public void drawCircles(){
        int max1 = 0;
        int max2 = 0;
        int max3 = 0;  //assuming integer elements in the array

        if(Measured_RSSI[1] > Measured_RSSI[0]) {
            max1 = 1;
        }
        else {
            max2 = 1;
        }
        if(Measured_RSSI[2] > Measured_RSSI[max1]) {
            max3 = max2;
            max2 = max1;
            max1 = 2;
        }
        else if(Measured_RSSI[2] > Measured_RSSI[max2]){
            max3 = max2;
            max2 = 2;
        }
        else {
            max3 = 2;
        }
        for (int i = 3; i < radii.length; i++)
        {
            if (Measured_RSSI[i] > Measured_RSSI[max1]) {
                max3 = max2;
                max2 = max1;
                max1 = i;
            }
            else if (Measured_RSSI[i] > Measured_RSSI[max2]) {
                max3 = max2;
                max2 = i;
            }
            else if (Measured_RSSI[i] > Measured_RSSI[max3]) {
                max3 = i;
            }
        }


        int radius = 0;
        //3044 (Blue)
        ImageView imgBlue = (ImageView) findViewById( R.id.imageViewCircleBlue);
        if(no_BSSID[0] == 0 || !(max3 == 0 || max2 == 0 || max1 == 0)) {
            imgBlue.setVisibility(View.GONE);
        }
        else {
            radius = radii[0];
            imgBlue.setVisibility(View.VISIBLE);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(2 * radius, 2 * radius);
            layoutParams.setMargins(AP_XCenter[0] - radius, AP_YCenter[0] - radius, 0, 0);
            imgBlue.setLayoutParams(layoutParams);
        }

        //3059 (Green)
        ImageView imgGreen = (ImageView) findViewById( R.id.imageViewCircleGreen);
        if(no_BSSID[1] == 0 || !(max3 == 1 || max2 == 1 || max1 == 1)) {
            imgGreen.setVisibility(View.GONE);
        }
        else {
            radius = radii[1];
            imgGreen.setVisibility(View.VISIBLE);
            RelativeLayout.LayoutParams layoutParamsGreen = new RelativeLayout.LayoutParams(2 * radius, 2 * radius);
            layoutParamsGreen.setMargins(AP_XCenter[1] - radius, AP_YCenter[1] - radius, 0, 0);
            imgGreen.setLayoutParams(layoutParamsGreen);
        }

        //3028 (Orange)
        ImageView imgOrange = (ImageView) findViewById( R.id.imageViewCircleOrange);
        if(no_BSSID[2] == 0 || !(max3 == 2 || max2 == 2 || max1 == 2)) {
            imgOrange.setVisibility(View.GONE);
        }
        else {
            radius = radii[2];
            imgOrange.setVisibility(View.VISIBLE);
            RelativeLayout.LayoutParams layoutParamsOrange = new RelativeLayout.LayoutParams(2 * radius, 2 * radius);
            layoutParamsOrange.setMargins(AP_XCenter[2] - radius, AP_YCenter[2] - radius, 0, 0);
            imgOrange.setLayoutParams(layoutParamsOrange);
        }

        //3102 (Purple)
        ImageView imgPurple = (ImageView) findViewById( R.id.imageViewCirclePurple);
        if(no_BSSID[3] == 0 || !(max3 == 3 || max2 == 3 || max1 == 3)) {
            imgPurple.setVisibility(View.GONE);
        }
        else {
            radius = radii[3];
            imgPurple.setVisibility(View.VISIBLE);
            RelativeLayout.LayoutParams layoutParamsPurple = new RelativeLayout.LayoutParams(2 * radius, 2 * radius);
            layoutParamsPurple.setMargins(AP_XCenter[3] - radius, AP_YCenter[3] - radius, 0, 0);
            imgPurple.setLayoutParams(layoutParamsPurple);
        }

        //3001 (LGreen)
        ImageView imgLGreen = (ImageView) findViewById( R.id.imageViewCircleLightGreen);
        if(no_BSSID[4] == 0 || !(max3 == 4 || max2 == 4 || max1 == 4)) {
            imgLGreen.setVisibility(View.GONE);
        }
        else {
            radius = radii[4];
            imgLGreen.setVisibility(View.VISIBLE);
            RelativeLayout.LayoutParams layoutParamsLGreen = new RelativeLayout.LayoutParams(2 * radius, 2 * radius);
            layoutParamsLGreen.setMargins(AP_XCenter[4] - radius, AP_YCenter[4] - radius, 0, 0);
            imgLGreen.setLayoutParams(layoutParamsLGreen);
        }

        //3002 (Red)
        ImageView imgRed = (ImageView) findViewById( R.id.imageViewCircleRed);
        if(no_BSSID[5] == 0 || !(max3 == 5 || max2 == 5 || max1 == 5)) {
            imgRed.setVisibility(View.GONE);
        }
        else {
            radius = radii[5];
            imgRed.setVisibility(View.VISIBLE);
            RelativeLayout.LayoutParams layoutParamsRed = new RelativeLayout.LayoutParams(2 * radius, 2 * radius);
            layoutParamsRed.setMargins(AP_XCenter[5] - radius, AP_YCenter[5] - radius, 0, 0);
            imgRed.setLayoutParams(layoutParamsRed);
        }
    }
}
