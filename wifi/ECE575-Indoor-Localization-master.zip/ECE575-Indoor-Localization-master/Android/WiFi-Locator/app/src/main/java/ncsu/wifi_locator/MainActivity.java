package ncsu.wifi_locator;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends ActionBarActivity {

    //Wifi libraries
    WifiManager wifi;
    BroadcastReceiver wifiDataReceiver = null;
    public Timer timerScanAPs;
    boolean shouldScan = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Enable WiFi
        wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        if (!wifi.isWifiEnabled())
        {
            Toast.makeText(getApplicationContext(), "wifi is disabled..making it enabled", Toast.LENGTH_LONG).show();
            wifi.setWifiEnabled(true);
        }
        wifiDataReceiver = new WifiScanReceiver();
        // register to receive the WiFi updates
        registerReceiver(wifiDataReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

        timerScanAPs = new Timer();	//timer to periodically update the location
        timerScanAPs.scheduleAtFixedRate(new ScanAPsTask(), 1000, 10000);

        TextView text = (TextView) findViewById(R.id.rssi);
        text.setText("RSSI values here!");
    }

    class ScanAPsTask extends TimerTask {
        @Override
        public void run() {
            shouldScan = true;
            if(wifi.startScan()){
                //worked correctly
            }
            else {
                //bad - might want error correction
            }
        }
    }

    // Register to get the Signal Strengths
    private class WifiScanReceiver extends BroadcastReceiver{
        // onReceive for the WiFi broadcast signal
        @Override
        public void onReceive(Context c, Intent intent) {
            if (shouldScan) {
                // Scan signal strengths if it is time
                List<ScanResult> results = wifi.getScanResults();
                Collections.sort(results, new Comparator<ScanResult>() {

                    public int compare(ScanResult lhs, ScanResult rhs) {
                        return lhs.level > rhs.level ? -1 : (lhs.level > rhs.level ) ? 1 : 0;
                    }
                });
                String displayText = "";
                int Max_results = results.size()> 5? 5:results.size();
                for (int i = 0; i < Max_results; i++) {
                    ScanResult result = results.get(i);
                    // Add this signal strength reading as a parameter where the name is the BSSID
                    String measurementString = result.BSSID + "=" + Integer.toString(result.level);

                    displayText = displayText + measurementString + "\n";
                }
                shouldScan = false;

                TextView text = (TextView) findViewById(R.id.rssi);
                text.setText(displayText);

            }
        }
    }
};
